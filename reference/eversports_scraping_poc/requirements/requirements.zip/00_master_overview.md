# Eversports × GHL Automation — Master Overview

## Context

You are building an automation product that sits on top of the **Eversports** booking platform and **GoHighLevel (GHL)** CRM. The system captures data from Eversports via daily scraping, syncs it into GHL contacts and custom fields, and runs automated use case workflows on top of that data.

The product is sold to Pilates and fitness studios that use Eversports as their booking platform. Each studio gets its own GHL sub-account.

---

## System Architecture

The system has two layers:

```
┌─────────────────────────────────────────────────┐
│              USE CASE LAYER                      │
│  Workflows that read from foundation and act     │
│  on contacts via GHL automations, AI messages,  │
│  tags, and notifications                         │
└─────────────────────────────────────────────────┘
                        ▲
                        │ reads from
┌─────────────────────────────────────────────────┐
│              FOUNDATION LAYER                    │
│  Data platform — scrapes Eversports, syncs to   │
│  GHL contacts. Use cases never scrape directly. │
└─────────────────────────────────────────────────┘
```

---

## Foundation Layer

The foundation layer is a data platform. It is not a use case. It runs continuously and keeps GHL contacts up to date with Eversports data. All use cases read exclusively from GHL — they never call Eversports directly. See `07_foundation_layer.md` for full technical spec.

**Technology stack:** Existing Eversports scraper (browser automation + CSV export URLs) → Google Sheets (intermediate store + delta engine) → GHL API (contact sync + tag engine + pipeline engine)

**Sync pattern:** Delta only — only changed fields pushed each run
**Schedule:** 07:00 · 13:00 · 19:00 daily (studio local time)

### 1. One-Time Historical Sync (runs once on setup)

- Pulls all 4 Eversports reports for the **past 30 days**
- Pulls active products and membership packages list
- Merges data into GHL contacts as baseline
- Creates contacts in GHL if they don't exist
- Populates all custom fields (see GHL Data Model below)

### 2. Daily Sync (runs 3× per day)

Pulls and merges the following Eversports reports into GHL:

| Report | Eversports Export |
|---|---|
| Active appointments & registrations | `?export=active` |
| All appointments & registrations | `?export=all` |
| Booking list | `?export=booking-list` |
| No-shows | `?export=no-show-all` |
| Active products & membership packages | (separate endpoint) |

- Downloads each report as CSV
- Merges into a single unified table per report type
- Updates GHL contact custom fields accordingly
- Applies or removes tags based on data changes

### 3. Today's Sessions & Bookings (live view, part of daily sync)

Captures per booking for today:

- Customer name and GHL contact ID
- Class/session name
- **Session start time**
- **Session end time** ← critical for time-based triggers in use cases
- Package type used to book (trial, card, membership)
- Sessions used vs. total sessions on package
- Attendance status (attended, no-show, upcoming)

### 4. Customer Authentication Sub-Workflow

Reusable sub-workflow called by use cases that require identity verification before engaging a customer via chat or AI.

**Steps:**
1. Collect customer phone number or email
2. Look up contact in GHL by phone or email
3. Send verification link via email
4. Wait for link click confirmation
5. Return authenticated contact ID to calling workflow

---

## GHL Data Model

### Custom Fields (set on GHL contact by foundation)

| Field Name | Type | Source |
|---|---|---|
| `eversports_customer_id` | Text | Eversports ID |
| `active_package_type` | Text | trial / card / membership |
| `active_package_name` | Text | e.g. "3-session trial" |
| `active_package_sessions_total` | Number | Total sessions on package |
| `active_package_sessions_used` | Number | Sessions used so far |
| `active_package_sessions_remaining` | Number | Calculated |
| `active_package_expiry_date` | Date | Package expiry |
| `missed_session_date` | Date | Date of most recent no-show |
| `missed_session_name` | Text | Class name that was missed |
| `missed_session_end_time` | DateTime | End time of missed session — used for send timing |
| `last_session_date` | Date | Most recent attended session |
| `last_session_end_time` | DateTime | End time of most recent session |
| `last_class_name` | Text | Name of last attended class |
| `total_sessions_attended` | Number | Lifetime count |
| `converted_package_name` | Text | First non-trial package purchased after trial |
| `conversion_date` | Date | Date trial conversion was detected |
| `no_show_count` | Number | Lifetime no-show count |
| `eversports_active_products` | Text (JSON) | Active products from Eversports — updated by foundation daily sync |
| `last_chatbot_interaction` | DateTime | Timestamp of most recent AI conversation — used for 7-day outbound re-trigger |
| `booking_history` | Text (JSON) | Last 30 days bookings |
| `products_purchased` | Text (JSON) | All products ever bought |
| `upcoming_session_name` | Text | Next booked session name — from active appointments report |
| `upcoming_session_date` | Date | Next booked session date |
| `upcoming_session_start_time` | DateTime | Next booked session start time |
| `upcoming_session_end_time` | DateTime | Next booked session end time |
| `active_sessions_data` | Text (JSON) | All upcoming sessions + availability |
| `reschedule_reason` | Text | Customer-provided reason when late cancel applies |
| `reschedule_requested_date` | Date | Customer's preferred new date |
| `reschedule_requested_time` | Text | Customer's preferred new time |
| `sessions_attended_this_month` | Number | For membership at-risk detection |
| `sessions_attended_last_month` | Number | For membership at-risk detection (50% drop check) |
| `last_booking_date` | Date | For card low-attendance detection (14 day check) |
| `pipeline_lead_stage` | Text | Current stage in lead-to-sale pipeline |
| `pipeline_card_stage` | Text | Current stage in card pipeline |
| `pipeline_membership_stage` | Text | Current stage in membership pipeline |

### GHL Tags (applied/removed by foundation and use cases)

| Tag | Applied when |
|---|---|
| `trial-active` | Customer has an active trial package |
| `trial-last-session` | Sessions used = total on trial package (today) |
| `trial-follow-up-active` | Added when use case 1 sequence starts |
| `trial-purchase-detected` | Foundation sync detects new non-trial product on a trial-only contact — used to trigger use case 02, removed after processing |
| `trial-converted` | Trial customer purchases a non-trial product |
| `trial-not-converted` | Completed 6 follow-up messages without converting |
| `opted-out` | Customer replied STOP to any sequence |
| `chatbot-active` | Chatbot conversation started — removed on any exit |
| `chatbot-sale-initiated` | AI sent purchase link — removed after purchase confirmed |
| `chatbot-converted` | Sale closed via chatbot — never removed |
| `no-show` | Marked no-show in Eversports today |
| `card-active` | Has an active card package |
| `membership-active` | Has an active membership |
| `low-attendance` | No booking in 14 days while card sessions remain |
| `membership-ready` | Card sessions remaining < 3 — upsell trigger point |
| `at-risk` | Membership attendance dropping — churn signal |
| `renewal-due` | Membership expiry within 14 days |
| `renewed` | New membership purchased after expiry |
| `churned` | Package expired with no renewal detected |
| `reschedule-pending` | Reschedule task created — pending admin action in Eversports |
| `lapsed` | No bookings in last 30 days |

---

## Use Case Layer

### Priority 1 — Quick Wins (sell first)

| # | Use Case | Trigger | Channels |
|---|---|---|---|
| 1 | Trial conversion follow-up | Last trial session detected by foundation | WhatsApp + Email |
| 2 | Trial → member tag | Foundation detects new non-trial product on contact whose only prior product name contains "trial" or "probe" | GHL notification + owner email |

### Priority 2 — High Value (sell second)

| # | Use Case | Trigger | Channels |
|---|---|---|---|
| 3 | No-show recovery | Foundation applies "no-show" tag · fires 2 hours after missed session end time | Email only · branched by package type |
| 4 | Sales consultant chatbot | Inbound: any message on WhatsApp/Email/Social · Outbound: Card Membership ready + Membership Renewal due pipeline stages | WhatsApp · Email · Social media |

### Priority 3 — Operational (sell third)

| # | Use Case | Trigger | Channels |
|---|---|---|---|
| 5 | Booking reschedule assistant | Inbound message with reschedule intent detected on any channel | Same channel as request + GHL task + owner notification |

---

## GHL Opportunity Pipelines

Three pipelines run in parallel. A contact can be in the lead pipeline AND one product pipeline simultaneously. See `03_ghl_pipelines.md` for full stage logic.

| Pipeline | Entry point | Purpose |
|---|---|---|
| Lead to sale | Contact created by foundation | Tracks every contact from first detection to first conversion |
| Card package | Card product detected in sync | Tracks card customers — attendance health, upsell to membership |
| Membership | Membership product detected in sync | Tracks members — retention, at-risk detection, renewal |

### Pipeline stage summary

**Lead to sale:** New lead → Trial sold → Trial booked → Converted (card) / Converted (membership) → Lost

**Card package:** Standard card → Low attendance warning → Membership ready → Converted → Churned

**Membership:** Active → At risk → Renewal due → Renewed → Churned

---

## GHL Sub-Account Settings

Set once per studio on onboarding. Stored as GHL custom values at sub-account level.

| Setting | Description | Example |
|---|---|---|
| `late_cancel_window_hours` | Hours before session that triggers late cancellation policy | 24 |
| `studio_owner_email` | Email for admin notifications across all use cases | owner@studio.com |
| `studio_owner_name` | Owner first name for email salutations | Anna |
| `studio_name` | Studio name injected into all AI prompts | Flow Pilates |
| `studio_active_promotions` | Current promotions — updated manually by owner in GHL custom values · injected into AI prompts · NOT a contact-level field | "Jan offer: 10% off membership" |

---

## General Design Principles

- **Foundation owns all data. Use cases own all logic.** No use case scrapes Eversports directly.
- **GHL is the single source of truth** for contact state, tags, and workflow control.
- **AI messages are always generated per customer** using their actual data from GHL custom fields — never generic templates.
- **STOP handling is mandatory** on every sequence from message 2 onwards. GHL listens for the keyword "STOP" and removes the contact from automation immediately.
- **Conversion exit is always active** — if a contact converts at any point in any sequence, the sequence ends immediately and they are re-tagged.
- **Timing guard for time-based sends** — classes run 08:00–21:00. Any calculated send time at or after 21:00 is held and sent at 09:00 the following morning. Sessions ending before 19:00 always send same day (+2h). Sessions ending at 19:00 or later roll to next morning.
- **Authentication is session-scoped** — `auth_verified` is a session variable only, never stored permanently on the contact. Every new conversation requires re-verification.
- **Owner notifications follow the 3-action standard** — GHL internal notification + GHL task assigned to owner + email to owner. Applied consistently across all use cases that notify the studio owner.
