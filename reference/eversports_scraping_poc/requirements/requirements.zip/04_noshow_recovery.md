# Use Case 03 — No-Show Recovery

## Overview

**Goal:** When any customer no-shows a session, send a single warm check-in email 2 hours after the missed session end time. Message tone and context vary by package type (trial / card / membership). No follow-up messages. Log the event as a GHL internal note.

**Trigger source:** Foundation layer — no-show report (daily sync)
**Channels:** Email only
**GHL role:** Trigger on tag, wait timer, branch by package type, log note, remove tag
**AI role:** Generate personalised email per customer per package type
**Repeat behaviour:** Fires independently every time a customer no-shows — no suppression

---

## Detection Logic

The foundation's daily no-show report sync does the following for each no-show detected today:

```
FOR each contact marked no-show in today's Eversports no-show report:
  Set custom field: missed_session_date = today
  Set custom field: missed_session_name = class name
  Set custom field: missed_session_end_time = session end time
  Apply GHL tag: "no-show"
```

This tag fires the use case 03 GHL automation.

---

## Workflow Diagram Description

```
[Foundation: no-show report synced → tag "no-show" applied to contact]
        │
        ▼
[GHL trigger: tag "no-show" applied]
        │
        ▼
[Wait: missed_session_end_time + 2 hours]
[Guard: if send time > 21:00 → reschedule to 09:00 next morning]
        │
        ▼
[Branch: check active_package_type]
   ┌────────────┬────────────┬────────────┐
   │            │            │            │
 Trial        Card      Membership    (future)
   │            │            │
   ▼            ▼            ▼
[AI email   [AI email   [AI email
 trial msg]  card msg]   member msg]
   │            │            │
   └────────────┴────────────┘
                │
                ▼
[GHL: add internal note to contact]
        │
        ▼
[GHL: remove tag "no-show"]
        │
        ▼
[Done]
```

---

## Phase 1 — Trigger

**GHL trigger:** Contact tag added = `no-show`

### Timing calculation

Classes run between 08:00 and 21:00 (earliest session ends 08:00, latest ends 21:00).

```
send_time = missed_session_end_time + 2 hours

IF send_time > 21:00:
  # Session ended at 19:00 or later → +2h would be 21:00 or later
  # Send next morning instead
  send_time = tomorrow at 09:00
```

This means:
- Sessions ending before 19:00 → email sends same day (e.g. 18:00 end → 20:00 send ✓)
- Sessions ending at 19:00 → email sends at 21:00 — on the boundary, reschedule to 09:00 next morning
- Sessions ending at 20:00 or 21:00 → email sends next morning at 09:00

The latest same-day send is 20:59. Any calculated time at or after 21:00 rolls to next morning.

---

## Phase 2 — Package Type Branch

GHL reads `active_package_type` custom field (set by foundation) and routes to the appropriate AI message generation step.

```
IF active_package_type contains "trial" OR "probe":
  → generate trial email
ELSE IF active_package_type == "card":
  → generate card email
ELSE IF active_package_type == "membership":
  → generate membership email
ELSE:
  → generate generic email (fallback)
```

---

## AI Email Prompts

All emails are AI-generated. No templates with placeholders — full AI generation using customer data from GHL custom fields.

### Shared data fields injected into all prompts

- `contact.first_name`
- `contact.missed_session_name`
- `contact.missed_session_date`
- `contact.active_package_name`
- `account.studio_name`

---

### Email — Trial customer

**Tone:** Warm, encouraging, understanding. Acknowledge this was a trial session they missed. No rebooking offer — just genuine care.

```
You are a warm assistant for [studio_name], a Pilates studio.

A customer missed their trial class today and you want to check in on them warmly.

Write a short, friendly email with the following qualities:
- Acknowledge they missed their session today without making them feel guilty
- Express genuine care — life gets busy, it happens
- Mention you'd love to see them back and that their trial is still there for them
- Keep it light and warm — no pressure, no offer, no link
- Under 100 words. Include a subject line.

Customer first name: [first_name]
Class missed: [missed_session_name]
Trial package: [active_package_name]
Studio name: [studio_name]
```

---

### Email — Card customer

**Tone:** Friendly and casual. They're already a paying customer. Acknowledge the miss without making it awkward. Subtle reminder that their session is still waiting.

```
You are a warm assistant for [studio_name], a Pilates studio.

A card customer missed their class today. Write a brief, friendly check-in email.

Guidelines:
- Warm and casual — they're already part of the community
- Acknowledge the missed session lightly — no guilt
- Gently remind them their session on their card is still there
- Do not offer rebooking links or discounts
- Under 100 words. Include a subject line.

Customer first name: [first_name]
Class missed: [missed_session_name]
Package: [active_package_name]
Studio name: [studio_name]
```

---

### Email — Membership customer

**Tone:** Warm and community-focused. Members have an ongoing relationship with the studio. Lean into consistency and belonging — missing one class is fine, the practice continues.

```
You are a warm assistant for [studio_name], a Pilates studio.

A member missed their class today. Write a brief, warm check-in email.

Guidelines:
- Acknowledge the missed class with complete understanding — no guilt at all
- Lean into the consistency angle: one missed class doesn't break a practice
- Reinforce their sense of belonging to the studio community
- No offers, no links, no rebooking push
- Under 100 words. Include a subject line.

Customer first name: [first_name]
Class missed: [missed_session_name]
Membership: [active_package_name]
Studio name: [studio_name]
```

---

### Email — Generic fallback (unknown package type)

Used when `active_package_type` is empty or unrecognised.

```
You are a warm assistant for [studio_name], a Pilates studio.

A customer missed their class today. Write a brief, warm check-in email.

Guidelines:
- Acknowledge the missed class warmly — no guilt
- Express that you hope they are well
- No offers, no links, no rebooking push
- Under 100 words. Include a subject line.

Customer first name: [first_name]
Class missed: [missed_session_name]
Studio name: [studio_name]
```

---

## Phase 3 — Log & Close

### GHL internal note

After the email is sent, add an internal note to the contact:

```
Note content:
  No-show recovery email sent.
  Date: [missed_session_date]
  Class missed: [missed_session_name]
  Package type: [active_package_type]
  Email sent at: [actual_send_timestamp]
```

### Tag cleanup

```
Remove tag: "no-show"
```

Removing the tag is critical — it resets the contact so the next no-show event can trigger the automation again cleanly. Without this, the tag would already be present and GHL would not re-fire the trigger.

---

## Timing Table

| Message | Channel | Timing | Notes |
|---|---|---|---|
| 1 (only) | Email | `missed_session_end_time` + 2 hours | Guard: max 21:00, else 09:00 next morning |

No follow-up messages. No STOP handling needed (single email, no sequence).

---

## Exit Conditions

This use case has a single linear path — no branching exits.

| Exit | Condition | GHL actions |
|---|---|---|
| Complete | Email sent, note added, tag removed | Done — automation ends |

---

## GHL Implementation Notes

### Tags used by this use case

| Tag | Applied by | Removed by |
|---|---|---|
| `no-show` | Foundation sync | This workflow after email sent |

### Custom fields read by this use case

| Field | Used for |
|---|---|
| `missed_session_end_time` | Calculate send time |
| `missed_session_name` | AI prompt context |
| `missed_session_date` | GHL note log |
| `active_package_type` | Branch logic |
| `active_package_name` | AI prompt context |

### Custom fields written by foundation for this use case

| Field | Value |
|---|---|
| `missed_session_date` | Date of the no-show |
| `missed_session_name` | Class name that was missed |
| `missed_session_end_time` | End time of the missed session |

### Repeat no-show behaviour

This automation fires independently for every no-show event. There is no suppression logic — if a customer no-shows three times in a month, they receive three separate emails. The tag removal at the end of each run ensures the trigger fires cleanly each time.

The `no_show_count` field (maintained by foundation) accumulates over time and can be used by future use cases (e.g. after 3 no-shows, escalate to a different workflow or flag for manual follow-up).

---

## Relationship to Pipelines

No-show events do not move contacts between pipeline stages directly. However:

- A card customer in "Low attendance warning" stage who also no-shows will receive this email alongside whatever re-engagement automation the card pipeline triggers.
- A membership customer in "At risk" stage who no-shows will receive this email. The at-risk pipeline trigger and this use case run independently.
- Future use cases may use `no_show_count` to move contacts to a pipeline stage (e.g. "Chronic no-show" as a sub-stage).

---

## Open Questions / To Confirm

- [ ] Should the email be sent even if the customer has already cancelled the booking before the session (i.e. a late cancellation that became a no-show by Eversports rules)? Or only true no-shows where they did not cancel at all?
- [ ] Does Eversports distinguish between "no-show" and "late cancellation" in the no-show export report?
- [ ] Should the generic fallback email be used, or should unknown package types be skipped and flagged instead?
