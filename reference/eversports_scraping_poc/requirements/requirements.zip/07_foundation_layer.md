# Foundation Layer — Full Spec

## Overview

The foundation is the data platform that all use cases sit on top of. It extracts data from Eversports, stores it in Google Sheets as an intermediate layer, computes deltas, syncs changed fields to GHL contacts via API, evaluates tag rules, and moves contacts through pipeline stages. Use cases never touch Eversports directly — they only read from GHL.

**Technology stack:**
- Scraper: existing tool (browser automation via Playwright/Selenium + CSV export URL download)
- Intermediate store: Google Sheets
- CRM: GoHighLevel (GHL) via API
- Sync pattern: delta only — only changed fields are pushed each run
- Schedule: fixed times — 07:00, 13:00, 19:00 daily (studio local time)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│  LAYER 1 — Eversports data extraction               │
│  Scraper runs 3× daily + one-time 30-day historical │
│  Browser login + CSV export URL download            │
└────────────────────┬────────────────────────────────┘
                     │ raw CSV data
┌────────────────────▼────────────────────────────────┐
│  LAYER 2 — Google Sheet (intermediate + sync log)   │
│  Merge reports → one row per customer               │
│  Delta engine: compare current vs previous values   │
│  Flag special changes for tag engine                │
└────────────────────┬────────────────────────────────┘
                     │ delta change set per customer
┌────────────────────▼────────────────────────────────┐
│  LAYER 3 — GHL sync via API                         │
│  Contact match → push delta fields → tag engine     │
│  → pipeline engine → sync log                       │
└─────────────────────────────────────────────────────┘
```

---

## Layer 1 — Eversports Data Extraction

### Authentication

The scraper uses browser automation (Playwright/Selenium) to log into Eversports with stored credentials. Session cookies are reused where possible to minimise login frequency.

### Reports downloaded each run

Each run downloads all 5 report types as CSV via their export URLs:

| Report | Export URL parameter | Fields captured |
|---|---|---|
| Active appointments | `?export=active` | Customer name, email, phone, class name, date, start time, end time, package used, status |
| All appointments | `?export=all` | Full booking history including past sessions |
| Booking list | `?export=booking-list` | Package type per booking, sessions used, sessions total |
| No-shows | `?export=no-show-all` | Customers who no-showed, class name, date, session times |
| Active products & memberships | (separate endpoint) | Product name, type, expiry date, sessions remaining |

### One-time historical sync (runs once on setup)

On first run only, the scraper pulls the past 30 days of data for all reports. This populates baseline data for all existing Eversports customers into GHL before any use cases go live.

```
historical_sync_flag = read from Google Sheet config tab
IF historical_sync_flag == "complete":
  → skip historical sync, run normal daily sync
ELSE:
  → run historical sync for past 30 days
  → set historical_sync_flag = "complete"
```

### Today's sessions & bookings (special capture)

Within the active appointments report, the scraper filters for sessions occurring today and captures:

```
For each today's booking:
  - customer_email (match key)
  - session_name
  - session_date (today)
  - session_start_time
  - session_end_time         ← critical for use case 01 and 03 timing
  - package_type_used        ← trial / card / membership
  - sessions_used_today      ← increments active_package_sessions_used
  - attendance_status        ← attended / no-show / upcoming
```

---

## Layer 2 — Google Sheet Structure

### Sheet tabs

| Tab name | Purpose |
|---|---|
| `contacts` | One row per Eversports customer — all fields, current + previous values |
| `sync_log` | One row per sync run — timestamp, stats, errors |
| `config` | Studio settings: sync times, historical_sync_flag, studio sub-account ID |
| `products` | Active products and memberships list — updated each run |
| `no_shows` | Today's no-shows — reset each run |
| `sessions_today` | Today's sessions — reset each run |

### `contacts` tab schema

Each row represents one Eversports customer. Columns:

**Identity**
- `eversports_customer_id` — Eversports customer ID
- `email` — primary match key
- `phone` — fallback match key
- `first_name`
- `last_name`
- `ghl_contact_id` — populated after first GHL sync

**Active package (current)**
- `active_package_type` — trial / card / membership
- `active_package_name`
- `active_package_sessions_total`
- `active_package_sessions_used`
- `active_package_sessions_remaining` — calculated: total - used
- `active_package_expiry_date`

**Active package (previous — for delta)**
- `prev_active_package_type`
- `prev_active_package_name`
- `prev_active_package_sessions_remaining`
- `prev_active_package_expiry_date`
- `prev_products_purchased` — JSON string of prior products list

**Session data**
- `last_session_date`
- `last_session_end_time`
- `last_class_name`
- `upcoming_session_name`
- `upcoming_session_date`
- `upcoming_session_start_time`
- `upcoming_session_end_time`
- `total_sessions_attended`
- `sessions_attended_this_month`
- `sessions_attended_last_month`
- `last_booking_date`
- `no_show_count`
- `missed_session_date`
- `missed_session_name`
- `missed_session_end_time`

**Products**
- `products_purchased` — JSON string: all products ever bought
- `converted_package_name` — first non-trial package purchased
- `conversion_date`

**Sync metadata**
- `last_sync_timestamp` — datetime of most recent successful sync
- `ghl_sync_status` — synced / pending / error
- `ghl_last_updated` — datetime of last GHL API write

### Delta engine logic

Runs after each scrape, before GHL sync:

```python
for each customer in contacts_tab:
  change_set = {}

  for each field in syncable_fields:
    current_value = contacts_tab[customer][field]
    previous_value = contacts_tab[customer]["prev_" + field]

    if current_value != previous_value:
      change_set[field] = current_value

  # Special change flags (used by tag engine)
  flags = {}

  # New non-trial product detected
  if (
    len(prev_products) == 1
    and is_trial(prev_products[0])
    and any(not is_trial(p) for p in current_products)
  ):
    flags["trial_purchase_detected"] = True
    flags["new_package_name"] = first_non_trial(current_products)

  # Last trial session detected
  if (
    is_trial(active_package_type)
    and active_package_sessions_remaining == 0
    and last_session_date == today
  ):
    flags["trial_last_session"] = True

  # No-show detected today
  if customer in todays_no_shows:
    flags["no_show_today"] = True
    flags["missed_session_end_time"] = todays_no_shows[customer].end_time

  # Attendance drop (membership at-risk)
  if sessions_attended_this_month < (sessions_attended_last_month * 0.5):
    flags["attendance_drop_50"] = True

  # Last booking date > 14 days ago (card low attendance)
  if last_booking_date < today - 14:
    flags["no_booking_14_days"] = True

  # Membership expiry within 14 days
  if active_package_expiry_date <= today + 14:
    flags["renewal_due"] = True

  store change_set and flags for GHL sync step
```

---

## Layer 3 — GHL Sync

### Step 1 — Contact matching

For each customer with a non-empty change set or flags:

```python
# Search GHL by email
ghl_contact = ghl_api.search_contacts(email=customer.email)

if not ghl_contact and customer.phone:
  # Fallback: search by phone
  ghl_contact = ghl_api.search_contacts(phone=customer.phone)

if not ghl_contact:
  # Create new contact
  ghl_contact = ghl_api.create_contact({
    "email": customer.email,
    "phone": customer.phone,
    "firstName": customer.first_name,
    "lastName": customer.last_name,
    "tags": ["new-contact"]
  })
  log("Created new GHL contact for: " + customer.email)

# Store GHL contact ID in Google Sheet
contacts_tab[customer]["ghl_contact_id"] = ghl_contact.id
```

### Step 2 — Push delta fields to GHL

```python
if change_set is not empty:
  ghl_api.update_contact(
    contact_id=ghl_contact.id,
    custom_fields=change_set
  )
  contacts_tab[customer]["ghl_sync_status"] = "synced"
  contacts_tab[customer]["ghl_last_updated"] = now()
```

### Step 3 — Tag engine

Evaluate tag rules against flags and current field values. Apply or remove tags via GHL API:

```python
tag_rules = [

  # Trial tags
  {
    "condition": flags.trial_last_session == True,
    "apply": ["trial-last-session"],
    "remove": []
  },
  {
    "condition": is_trial(active_package_type) and sessions_remaining > 0,
    "apply": ["trial-active"],
    "remove": []
  },
  {
    "condition": flags.trial_purchase_detected == True,
    "apply": ["trial-purchase-detected"],
    "remove": ["trial-active"]
  },

  # No-show tag
  {
    "condition": flags.no_show_today == True,
    "apply": ["no-show"],
    "remove": []
    # Note: "no-show" tag is removed by use case 03 after email is sent
  },

  # Card tags
  {
    "condition": is_card(active_package_type),
    "apply": ["card-active"],
    "remove": ["trial-active"]
  },
  {
    "condition": flags.no_booking_14_days == True and is_card(active_package_type),
    "apply": ["low-attendance"],
    "remove": []
  },
  {
    "condition": is_card(active_package_type) and sessions_remaining < 3,
    "apply": ["membership-ready"],
    "remove": ["low-attendance"]
  },

  # Membership tags
  {
    "condition": is_membership(active_package_type),
    "apply": ["membership-active"],
    "remove": ["card-active", "trial-active"]
  },
  {
    "condition": (
      is_membership(active_package_type) and
      (last_session_date < today - 14 or flags.attendance_drop_50)
    ),
    "apply": ["at-risk"],
    "remove": []
  },
  {
    "condition": flags.renewal_due == True and is_membership(active_package_type),
    "apply": ["renewal-due"],
    "remove": []
  },

  # Renewed membership
  {
    "condition": (
      is_membership(active_package_type) and
      new membership product detected and
      prev_active_package_expiry_date <= today + 14
    ),
    "apply": ["renewed", "membership-active"],
    "remove": ["renewal-due", "at-risk", "churned"]
  },

  # Lapsed
  {
    "condition": last_booking_date < today - 30,
    "apply": ["lapsed"],
    "remove": []
  },

  # Churned
  {
    "condition": (
      active_package_expiry_date < today and
      not any active package detected
    ),
    "apply": ["churned"],
    "remove": ["card-active", "membership-active", "renewal-due"]
  },
]

for rule in tag_rules:
  if rule.condition:
    ghl_api.apply_tags(contact_id, rule.apply)
    ghl_api.remove_tags(contact_id, rule.remove)
```

### Step 4 — Pipeline engine

Evaluate pipeline stage rules and move contact if stage has changed:

```python
pipeline_rules = [

  # Lead pipeline
  {
    "pipeline": "lead_to_sale",
    "stage": "Trial sold",
    "condition": "trial-active" in contact.tags
  },
  {
    "pipeline": "lead_to_sale",
    "stage": "Trial booked",
    "condition": "trial-active" in tags and total_sessions_attended >= 1
  },
  {
    "pipeline": "lead_to_sale",
    "stage": "Converted (card)",
    "condition": "trial-converted" in tags and is_card(converted_package_name)
  },
  {
    "pipeline": "lead_to_sale",
    "stage": "Converted (membership)",
    "condition": "trial-converted" in tags and is_membership(converted_package_name)
  },
  {
    "pipeline": "lead_to_sale",
    "stage": "Lost",
    "condition": "trial-not-converted" in tags
  },

  # Card pipeline
  {
    "pipeline": "card_package",
    "stage": "Standard card",
    "condition": "card-active" in tags and "low-attendance" not in tags
  },
  {
    "pipeline": "card_package",
    "stage": "Low attendance warning",
    "condition": "low-attendance" in tags
  },
  {
    "pipeline": "card_package",
    "stage": "Membership ready",
    "condition": "membership-ready" in tags
  },
  {
    "pipeline": "card_package",
    "stage": "Churned",
    "condition": "churned" in tags and prev_package was card
  },

  # Membership pipeline
  {
    "pipeline": "membership",
    "stage": "Active",
    "condition": "membership-active" in tags and "at-risk" not in tags
  },
  {
    "pipeline": "membership",
    "stage": "At risk",
    "condition": "at-risk" in tags
  },
  {
    "pipeline": "membership",
    "stage": "Renewal due",
    "condition": "renewal-due" in tags
  },
  {
    "pipeline": "membership",
    "stage": "Churned",
    "condition": "churned" in tags and prev_package was membership
  },
]

for rule in pipeline_rules:
  current_stage = ghl_api.get_opportunity_stage(contact_id, rule.pipeline)
  if rule.condition and current_stage != rule.stage:
    ghl_api.update_opportunity_stage(contact_id, rule.pipeline, rule.stage)
    log_pipeline_move(contact_id, rule.pipeline, current_stage, rule.stage)
```

---

## Sync Log

After each full run, write one row to the `sync_log` tab:

| Column | Value |
|---|---|
| `run_timestamp` | Start time of sync run |
| `run_type` | daily / historical |
| `contacts_processed` | Total Eversports customers in reports |
| `contacts_updated_ghl` | Contacts where GHL fields were changed |
| `contacts_created_ghl` | New GHL contacts created this run |
| `tags_applied` | Total tag apply operations |
| `tags_removed` | Total tag remove operations |
| `pipeline_moves` | Total pipeline stage changes |
| `errors` | Count of API errors |
| `error_details` | JSON list of failed contact emails + error messages |
| `run_duration_seconds` | Total time for full run |

---

## Error Handling

### GHL API failure on a single contact

```python
MAX_RETRIES = 3
BACKOFF = [2, 5, 10]  # seconds

for attempt in range(MAX_RETRIES):
  try:
    ghl_api.update_contact(...)
    break
  except GHLAPIError as e:
    if attempt < MAX_RETRIES - 1:
      sleep(BACKOFF[attempt])
    else:
      log_error(contact.email, str(e))
      contacts_tab[customer]["ghl_sync_status"] = "error"
      continue  # skip this contact, continue run
```

### Scrape failure (Eversports unreachable)

```python
try:
  download_reports()
except ScrapeError:
  log_sync_error("Eversports scrape failed at " + now())
  send_alert_email(studio_owner_email, "Foundation sync failed — Eversports unreachable")
  abort_run()  # do not push stale data to GHL
```

### Partial report failure

If one report fails to download but others succeed:

```python
# Update only fields sourced from successfully downloaded reports
# Log which report failed
# Do not clear existing GHL field values for the failed report's fields
```

---

## Helper Functions

```python
def is_trial(package_name_or_type):
  return "trial" in str(package_name_or_type).lower() or \
         "probe" in str(package_name_or_type).lower()

def is_card(package_name_or_type):
  return not is_trial(package_name_or_type) and \
         not is_membership(package_name_or_type)

def is_membership(package_name_or_type):
  return "membership" in str(package_name_or_type).lower() or \
         "mitgliedschaft" in str(package_name_or_type).lower()
  # Note: confirm exact membership product name patterns with studio

def first_non_trial(products_list):
  return next(
    p for p in products_list
    if not is_trial(p["name"])
  )
```

---

## GHL API Calls Used

| Operation | GHL API endpoint |
|---|---|
| Search contact by email | `GET /contacts/search?email=` |
| Search contact by phone | `GET /contacts/search?phone=` |
| Create contact | `POST /contacts/` |
| Update contact fields | `PUT /contacts/{id}` |
| Apply tags | `POST /contacts/{id}/tags` |
| Remove tags | `DELETE /contacts/{id}/tags` |
| Get opportunity stage | `GET /opportunities?contact_id=` |
| Update opportunity stage | `PUT /opportunities/{id}` |
| Create opportunity | `POST /opportunities/` |

---

## Configuration (per studio, stored in Google Sheet config tab)

| Key | Description | Example |
|---|---|---|
| `studio_id` | Eversports studio ID in export URLs | `Yneu3U` |
| `ghl_subaccount_id` | GHL sub-account ID | `abc123` |
| `ghl_api_key` | GHL API key for this sub-account | `pk_xxx` |
| `sync_times` | Daily sync schedule | `07:00,13:00,19:00` |
| `timezone` | Studio local timezone | `Europe/Vienna` |
| `historical_sync_flag` | Whether 30-day historical sync has run | `complete` / `pending` |
| `late_cancel_window_hours` | Studio late cancel policy window | `24` |
| `studio_owner_email` | Owner notification email | `owner@studio.com` |
| `studio_name` | Injected into AI prompts | `Flow Pilates` |
| `eversports_username` | Scraper login credential | stored securely |
| `eversports_password` | Scraper login credential | stored securely |

---

## Foundation Fields Added to Master Data Model

The following fields are added or confirmed by the foundation spec:

| Field | Type | Set by | Notes |
|---|---|---|---|
| `ghl_contact_id` | Text | Foundation on first sync | Stored in Google Sheet |
| `eversports_customer_id` | Text | Foundation | Eversports internal customer ID |
| `active_package_sessions_remaining` | Number | Foundation (calculated) | total - used |
| `sessions_attended_this_month` | Number | Foundation | Rolling month count |
| `sessions_attended_last_month` | Number | Foundation | Prior month count for at-risk check |
| `last_booking_date` | Date | Foundation | For 14-day card inactivity check |
| `missed_session_date` | Date | Foundation | Date of most recent no-show |
| `missed_session_name` | Text | Foundation | Class name of no-show |
| `missed_session_end_time` | DateTime | Foundation | Used by use case 03 send timing |
| `upcoming_session_name` | Text | Foundation | Next booked class |
| `upcoming_session_date` | Date | Foundation | Next booking date |
| `upcoming_session_start_time` | DateTime | Foundation | For late cancel policy check |
| `upcoming_session_end_time` | DateTime | Foundation | |
| `active_sessions_data` | Text (JSON) | Foundation | All upcoming sessions + open slots |

---

## Open Questions / To Confirm

- [ ] What exact product name patterns does each studio use for cards vs memberships? The `is_card()` and `is_membership()` helper functions need the correct keyword list per studio (e.g. German studios may use "Karte", "Mitgliedschaft").
- [ ] Does the Eversports active appointments report include session end time, or only start time? If start time only, end time must be calculated from class duration (which may need a separate data source).
- [ ] Does the Eversports no-show report include session end time, or only session date and start time?
- [ ] Are Eversports credentials stored securely outside the Google Sheet (e.g. environment variables on the server)? The config tab should never contain plaintext passwords.
- [ ] Does the active products report include a product category field (card vs membership), or is classification purely by name pattern?
- [ ] For the `active_sessions_data` field (used by reschedule assistant for availability check) — does Eversports export open slot counts per session, or only confirmed bookings?
