# Use Case 04 — Sales Consultant Chatbot

## Overview

**Goal:** An AI-powered sales consultant that operates in two modes — inbound (responding to customer messages across all channels) and outbound (proactively reaching out based on pipeline stage triggers). The AI handles the full conversation, recommends the best product based on the customer's profile, and sends a purchase link. It hands off to a human when a complex question is detected.

**Trigger source (inbound):** Any inbound message on WhatsApp, Email, Instagram, Facebook
**Trigger source (outbound):** Pipeline stage changes — Card: Membership ready · Membership: Renewal due
**Channels:** WhatsApp · Email · Social media (Instagram, Facebook)
**GHL role:** Conversation routing, authentication, profile injection, tag management, human assignment, notifications
**AI role:** Full conversation handling — intent detection, product recommendation, objection handling, handoff detection
**Products scope:** Cards · memberships · active studio promotions (from GHL custom field + Eversports foundation sync)

---

## Mode A — Inbound

### Trigger

Any inbound message received on a connected channel (WhatsApp, Email, Instagram, Facebook) fires the GHL conversation AI workflow.

**GHL trigger:** Inbound message received on any connected channel

### Step 1 — Authentication

Before loading any customer data, the authentication sub-workflow runs.

`auth_verified` is session-scoped — it is set to `true` during a conversation and reset to `false` when the conversation session ends. It is never stored permanently on the contact. This means every new conversation requires re-verification.

```
IF auth_verified == true (verified earlier in THIS session):
  → skip authentication, proceed to Step 2
ELSE:
  → run authentication sub-workflow (see foundation layer spec)
  → on success: set session variable auth_verified = true (not a contact field)
  → on failure: send message "We couldn't verify your identity. Please contact us directly."
                end workflow
```

### Step 2 — Load customer profile

Pull the following fields from the GHL contact and inject into the AI system prompt:

```
- first_name
- active_package_type
- active_package_name
- active_package_sessions_remaining
- active_package_expiry_date
- last_session_date
- last_class_name
- total_sessions_attended
- no_show_count
- booking_history (last 30 days)
- products_purchased (all time)
- pipeline_lead_stage
- pipeline_card_stage
- pipeline_membership_stage
- available_products (from GHL custom field: eversports_active_products)
- active_promotions (from GHL custom field: studio_active_promotions)
```

### Step 3 — AI conversation loop

The AI handles the conversation turn by turn. Each incoming message is passed to the AI with the full customer profile and conversation history.

#### AI system prompt

```
You are a warm, knowledgeable sales consultant for [studio_name], a Pilates studio.
You are chatting with [first_name] via [channel].

Your role is to:
- Understand what the customer needs or is asking
- Recommend the most suitable product based on their history and current package
- Answer questions about classes, packages, and studio offerings
- Guide them toward a purchase naturally — never pushy
- Send the purchase link when they are ready to buy

Customer profile:
- Current package: [active_package_name] ([active_package_sessions_remaining] sessions remaining)
- Package expires: [active_package_expiry_date]
- Last class attended: [last_class_name] on [last_session_date]
- Total sessions attended: [total_sessions_attended]
- Past products: [products_purchased]
- Booking history (last 30 days): [booking_history]

Available products:
[available_products]

Active promotions:
[active_promotions]

Tone guidelines:
- Warm, personal, boutique studio feel
- Never use pressure tactics or urgency language
- No discounts unless a promotion is in active_promotions
- Match the channel tone: WhatsApp = casual, Email = slightly more formal, Social = friendly

Handoff rule:
- If the customer asks something you cannot confidently answer (pricing disputes,
  injury-specific advice, class scheduling changes, billing issues, complaints),
  respond warmly and say a team member will follow up shortly.
- Include the phrase "HANDOFF_REQUIRED" at the very end of your response
  (this is invisible to the customer and used to trigger the handoff workflow).
```

#### Intent classification (AI evaluates each message)

```
PURCHASE_INTENT    → customer signals readiness to buy
QUESTION           → customer asks about products, classes, schedule
OBJECTION          → customer expresses hesitation or concern
COMPLEX_QUESTION   → pricing dispute, injury, billing, complaint
GREETING           → casual opening, no clear intent yet
OTHER              → anything else
```

#### AI response logic per intent

```
PURCHASE_INTENT:
  → confirm which product fits best
  → send purchase link from available_products
  → tag: "chatbot-sale-initiated"

QUESTION:
  → answer using profile + available_products data
  → guide naturally toward recommendation

OBJECTION:
  → acknowledge concern empathetically
  → reframe with value, not pressure
  → do not offer discounts unless active_promotions applies

COMPLEX_QUESTION or HANDOFF_REQUIRED detected:
  → send warm holding message to customer
  → trigger human handoff (see below)

GREETING:
  → warm opening response
  → ask open question to understand their needs
```

### Step 4 — Human handoff

Triggered when AI response contains `HANDOFF_REQUIRED`.

**Three simultaneous GHL actions:**

```
1. Assign GHL conversation to studio owner user
2. GHL internal notification:
   Title: "Chatbot handoff — [first_name] [last_name]"
   Body: "Customer needs human assistance. View conversation: [GHL conversation link]"

3. Email to studio owner:
   Subject: "Action needed — chatbot handoff for [first_name] [last_name]"
   Body:
     [first_name] [last_name] is in a conversation that needs your attention.
     Package: [active_package_name]
     Pipeline stage: [pipeline_card_stage or pipeline_membership_stage]
     Conversation: [GHL conversation link]
     Contact profile: [GHL contact link]
```

**Customer-facing holding message (AI sends this before handoff):**

```
"Great question — let me get one of our team members to help you with that directly.
Someone will be in touch with you shortly, [first_name]!"
```

### Step 5 — Purchase confirmed

When the customer confirms purchase or foundation sync detects a new product on the contact:

```
Apply tag: "chatbot-converted"
Remove tag: "chatbot-active" (if present)
Update pipeline stage:
  IF new product is card → Card pipeline: Standard card
  IF new product is membership → Membership pipeline: Active
                               + Lead pipeline: Converted (membership)
GHL internal notification to owner:
  "Sale closed by chatbot — [first_name] purchased [product_name]"
```

---

## Mode B — Outbound

### Trigger 1 — Card pipeline: Membership ready

**Fires when:** Contact moves to "Membership ready" stage in card pipeline (`sessions_remaining < 3`)
**Channel:** WhatsApp
**One message only — no follow-up if no reply**

#### AI outbound prompt — card upsell

```
You are a warm sales consultant for [studio_name], a Pilates studio.

Write a short WhatsApp message to [first_name] who has been a card customer
and is running low on sessions ([sessions_remaining] sessions left on their [active_package_name]).

The message should:
- Feel personal and timely — they are close to finishing their card
- Highlight the value of switching to a membership (better value per session,
  no need to keep buying cards, uninterrupted practice)
- Include a direct link to view membership options: [membership_product_link]
- Be warm, not pushy. No discounts unless active_promotions is not empty.
- Under 90 words. No subject line needed (WhatsApp).

Customer first name: [first_name]
Sessions remaining: [sessions_remaining]
Current package: [active_package_name]
Sessions attended total: [total_sessions_attended]
Available memberships: [available_products filtered to memberships]
Active promotions: [active_promotions]
Studio name: [studio_name]
```

---

### Trigger 2 — Membership pipeline: Renewal due

**Fires when:** Contact moves to "Renewal due" stage in membership pipeline (expiry within 14 days)
**Channel:** Email
**One message only — no follow-up if no reply**

#### AI outbound prompt — membership renewal

```
You are a warm sales consultant for [studio_name], a Pilates studio.

Write a short renewal reminder email to [first_name] whose membership expires
on [active_package_expiry_date] (in [days_until_expiry] days).

The email should:
- Be warm and appreciate their loyalty as a member
- Gently remind them their membership is expiring soon
- Encourage them to renew to keep their practice uninterrupted
- Include a direct renewal link: [membership_renewal_link]
- Mention any active promotions if available
- Under 120 words. Include a subject line.

Customer first name: [first_name]
Membership: [active_package_name]
Expiry date: [active_package_expiry_date]
Days until expiry: [days_until_expiry]
Total sessions attended: [total_sessions_attended]
Active promotions: [active_promotions]
Studio name: [studio_name]
```

---

### Outbound reply handling

If the customer replies to an outbound message, the conversation transitions to inbound mode — the AI picks up the reply and continues the conversation loop (Mode A, Step 3 onwards). Authentication is skipped since the contact is already known from the pipeline trigger.

```
ON inbound reply to outbound message:
  SET session variable auth_verified = true (contact is known — pipeline trigger confirmed identity)
  → enter Mode A conversation loop at Step 3
```

### No-reply re-trigger logic

If the customer never replies to an outbound message and the pipeline stage has not changed after 7 days, the outbound message fires again on the next daily sync check:

```
ON daily sync:
  IF pipeline_card_stage == "Membership ready"
     AND last_chatbot_interaction < today - 7 days (or null):
    → re-send outbound card upsell message (WhatsApp)
    → update last_chatbot_interaction = now()

  IF pipeline_membership_stage == "Renewal due"
     AND last_chatbot_interaction < today - 7 days (or null):
    → re-send outbound renewal message (Email)
    → update last_chatbot_interaction = now()
```

This continues every 7 days until the customer replies, converts, or the pipeline stage changes (e.g. card expires → Churned, membership renews → Active).

---

## Product & Promotions Data

### Available products (foundation-synced)

Stored in GHL custom field: `eversports_active_products`
Format: JSON array

```json
[
  {
    "name": "10-session card",
    "type": "card",
    "price": 150,
    "link": "https://eversports.com/checkout/..."
  },
  {
    "name": "Monthly membership",
    "type": "membership",
    "price": 89,
    "link": "https://eversports.com/checkout/..."
  }
]
```

Updated by foundation daily sync from Eversports active products endpoint.

### Active promotions

Stored in GHL custom field: `studio_active_promotions`
Format: Text (plain language, studio owner updates manually in GHL)

Example: `"January offer: 10% off monthly membership until Jan 31"`

If empty: AI does not mention any promotions.

---

## Timing Table

| Mode | Trigger | Channel | Timing |
|---|---|---|---|
| Inbound | Customer sends message | WhatsApp / Email / Social | Immediate response |
| Outbound — card upsell | sessions_remaining < 3 | WhatsApp | Same day pipeline stage changes |
| Outbound — renewal | Expiry within 14 days | Email | Same day pipeline stage changes |

---

## Exit Conditions

| Exit | Condition | GHL actions |
|---|---|---|
| Sale closed | Purchase confirmed via chatbot | Tag `chatbot-converted`, update pipeline stages, notify owner |
| Human handoff | Complex question detected | Assign conversation, notify owner via GHL + email, pause AI |
| No reply (outbound) | Customer does not reply to outbound message | No action — conversation stays open, no follow-up sent |
| Auth failed | Customer cannot be verified | Send error message, end workflow |

---

## GHL Implementation Notes

### Tags used by this use case

| Tag | Applied by | Removed by |
|---|---|---|
| `chatbot-active` | This workflow on inbound start | This workflow on any exit |
| `chatbot-sale-initiated` | AI when purchase link sent | After purchase confirmed |
| `chatbot-converted` | This workflow on sale close | Never removed |
| `membership-ready` | Card pipeline (foundation) | This workflow on conversion |
| `renewal-due` | Membership pipeline (foundation) | This workflow on renewal |

### Custom fields read by this use case

| Field | Used for |
|---|---|
| `active_package_type` | Product recommendation logic |
| `active_package_name` | AI prompt context |
| `active_package_sessions_remaining` | Outbound card upsell trigger |
| `active_package_expiry_date` | Outbound renewal trigger + prompt |
| `booking_history` | AI context for personalisation |
| `products_purchased` | AI context — avoid recommending what they already had |
| `eversports_active_products` | Product list for AI recommendations |
| `studio_active_promotions` | Promotions for AI to mention |
| `pipeline_card_stage` | Outbound trigger condition |
| `pipeline_membership_stage` | Outbound trigger condition |

### Custom fields written by this use case

| Field | Value |
|---|---|
| `auth_verified` | Boolean — set true after successful authentication |
| `last_chatbot_interaction` | DateTime — timestamp of most recent AI conversation |

---

## Open Questions / To Confirm

- [ ] Which social media channels are connected to GHL? (Instagram DMs and Facebook Messenger require GHL social media integration to be enabled per sub-account.)
- [ ] Should the AI have a name (e.g. "Sara from [studio_name]") or remain anonymous as the studio itself?
- [ ] When the AI sends a purchase link, is it a direct Eversports checkout URL or a GHL-tracked link (for conversion attribution)?
- [ ] Should the outbound messages also go through authentication, or is pipeline stage alone sufficient to confirm identity for outbound?
- [ ] How should `days_until_expiry` be calculated — from today's date vs `active_package_expiry_date`? This needs to be computed at send time.
