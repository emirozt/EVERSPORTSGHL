# Use Case 05 — Booking Reschedule Assistant

## Overview

**Goal:** When a customer sends a reschedule request on any channel, the AI detects the intent, authenticates the customer, loads their current booking, checks the late cancellation policy, collects their preferred new slot, checks availability from foundation data, summarises the request, creates a GHL admin task, and sends a confirmation to the customer. Admin performs the actual change in Eversports.

**Trigger source:** Any inbound message on WhatsApp, Email, or Social media where reschedule intent is detected
**Channels:** WhatsApp · Email · Social media (same channel as request)
**GHL role:** Intent routing, authentication, task creation, notifications
**AI role:** Intent detection, conversation handling, policy check, availability check, summary generation
**Admin role:** Performs actual reschedule in Eversports after reviewing GHL task

---

## Workflow Diagram Description

```
[Inbound message — WhatsApp / Email / Social]
        │
        ▼
[Phase 1: AI detects reschedule intent]
  NOT reschedule → route to sales chatbot (use case 04)
  IS reschedule  → continue
        │
        ▼
[Authentication sub-workflow]
  Success → continue
  Failure → send error message, end workflow
        │
        ▼
[Load current booking from GHL]
  Session name · date · start time · package type
  late_cancel_window (from GHL sub-account setting)
        │
        ▼
[Phase 2: Late cancellation policy check]
  now > session_start_time − late_cancel_window?
  YES → inform customer · collect reason → store reschedule_reason → continue
  NO  → continue directly
        │
        ▼
[Phase 3: Collect preferred slot]
  Ask customer for preferred new date and time
        │
        ▼
[Check availability from foundation data]
  Match preferred_date + preferred_time against active sessions in GHL
  NOT available → ask for alternative preferred slot (loop back)
  AVAILABLE     → continue
        │
        ▼
[Phase 4: Summarise + task + notify]
  Summarise full request to customer for confirmation
        │
        ▼
  GHL: create admin task
  GHL: internal notification to owner
  Email: full request summary to studio owner
        │
        ▼
  Send confirmation message to customer (same channel as request)
        │
        ▼
[Done — admin action pending in Eversports]
```

---

## Phase 1 — Intent Detection & Routing

### GHL trigger

**Trigger:** Inbound message received on any connected channel

### AI intent classification

The AI reads the inbound message and classifies the primary intent:

```
RESCHEDULE  → customer wants to change an existing booking
CANCEL      → customer wants to cancel (future use case — route to admin directly)
PURCHASE    → customer wants to buy something → route to use case 04
QUESTION    → general inquiry → route to use case 04
OTHER       → unclear → ask clarifying question
```

Only `RESCHEDULE` intent continues in this workflow. All others are routed appropriately.

#### AI intent detection prompt

```
Classify the intent of the following customer message. Reply with ONE word only:
RESCHEDULE, CANCEL, PURCHASE, QUESTION, or OTHER.

Message: [inbound_message_text]
```

### Authentication

Run the shared authentication sub-workflow (see foundation layer spec).

```
IF auth_verified == true (already authenticated in session):
  → skip, proceed to loading booking
ELSE:
  → run authentication sub-workflow
  → on failure: reply "We couldn't verify your identity. Please contact us directly." · end
```

---

## Phase 2 — Load Current Booking

Pull from GHL contact custom fields (set by foundation):

```
- upcoming_session_name        (next booked class name)
- upcoming_session_date        (date of next booking)
- upcoming_session_start_time  (start time of next booking)
- upcoming_session_end_time    (end time of next booking)
- active_package_type          (trial / card / membership)
- active_package_name          (package name)
```

Pull from GHL sub-account settings:

```
- late_cancel_window_hours     (studio-configurable, e.g. 24)
```

### Confirm booking with customer

Before proceeding, the AI confirms which booking the customer wants to reschedule:

```
AI message:
"Hi [first_name]! I can see you have [upcoming_session_name] booked for
[upcoming_session_date] at [upcoming_session_start_time].
Is this the session you'd like to reschedule?"
```

If yes → continue.
If no → ask customer to specify which booking (note: foundation data currently stores next upcoming session only — if multiple bookings exist, flag for admin instead).

---

## Phase 3 — Late Cancellation Policy Check

### Policy calculation

```
late_cancel_threshold = upcoming_session_start_time − late_cancel_window_hours

IF current_time > late_cancel_threshold:
  late_cancellation_applies = TRUE
ELSE:
  late_cancellation_applies = FALSE
```

### If late cancellation applies

The AI informs the customer and collects a reason before proceeding:

```
AI message (generated, not templated):
"Just so you know, [first_name] — our policy considers this a late cancellation
as your session starts in less than [late_cancel_window_hours] hours.
We'll still process your request, but we do need to note the reason.
Could you let us know why you need to reschedule?"
```

Store customer's reply as: `reschedule_reason`

If late cancellation does NOT apply → skip reason collection, set `reschedule_reason = "N/A"`.

---

## Phase 4 — Collect Preferred Slot & Check Availability

### Ask for preferred slot

```
AI message:
"What date and time would work best for you, [first_name]?
I'll check if we have availability."
```

Store customer reply as:
- `preferred_date`
- `preferred_time`

### Availability check

Cross-reference `preferred_date` + `preferred_time` against the foundation's active sessions and bookings data stored in GHL:

```
Check: active_sessions_data (GHL custom field — JSON of upcoming sessions)

IF active_sessions_data is populated:
  IF preferred_date + preferred_time matches an available session slot:
    available = TRUE
    store: new_session_name, new_session_date, new_session_time
  ELSE:
    available = FALSE
    AI message: "Sorry, we don't have availability at that time.
                 Do you have another preferred date or time?"
    → loop back, ask again (max 3 attempts, then escalate to admin with note)

IF active_sessions_data is empty or unavailable:
  → fallback: do not check availability
  → pass preferred_date + preferred_time directly to admin task as "requested slot (unverified)"
  → note in admin task: "Availability not verified automatically — please check Eversports"
```

---

## Phase 5 — Summarise, Create Task, Notify

### Customer summary message

AI generates a summary on the same channel the request came in on:

```
AI message (generated):
"Here's a summary of your reschedule request, [first_name]:

  Original booking: [upcoming_session_name] on [upcoming_session_date] at [upcoming_session_start_time]
  Requested new slot: [new_session_name] on [new_session_date] at [new_session_time]
  [If late cancel applies]: Late cancellation noted · Reason: [reschedule_reason]

Our team will confirm your new booking shortly. You'll receive a confirmation on this channel once it's done."
```

### GHL admin task

```
Task title: "Reschedule request — [first_name] [last_name]"
Due: today (urgent)
Assigned to: studio owner

Task body:
  Customer: [first_name] [last_name]
  Contact link: [GHL contact URL]

  ORIGINAL BOOKING:
  Class: [upcoming_session_name]
  Date: [upcoming_session_date]
  Time: [upcoming_session_start_time]
  Package: [active_package_name]

  REQUESTED NEW SLOT:
  Class: [new_session_name]
  Date: [new_session_date]
  Time: [new_session_time]

  LATE CANCELLATION: [Yes / No]
  Reason (if applicable): [reschedule_reason]

  ACTION REQUIRED:
  1. Reschedule booking in Eversports
  2. Send confirmation to customer via [channel]
```

### GHL internal notification

```
Title: "Reschedule request — [first_name] [last_name]"
Body: "[first_name] wants to move [upcoming_session_name] from [upcoming_session_date]
       to [new_session_date] at [new_session_time]. Task created. Action required."
```

### Email to studio owner

```
Subject: "Reschedule request — [first_name] [last_name] · Action needed"
Body:
  Hi [owner_name],

  A reschedule request has been received and a task has been created in GHL.

  Customer: [first_name] [last_name]
  Original: [upcoming_session_name] · [upcoming_session_date] · [upcoming_session_start_time]
  New slot: [new_session_name] · [new_session_date] · [new_session_time]
  Late cancellation: [Yes / No]
  [If yes] Reason: [reschedule_reason]

  Please process this in Eversports and confirm with the customer.

  GHL task: [task link]
  Contact profile: [GHL contact link]
```

---

## GHL Sub-Account Settings Required

| Setting | Description | Example |
|---|---|---|
| `late_cancel_window_hours` | Hours before session that triggers late cancel policy | 24 |
| `studio_owner_email` | Email address for admin notifications | owner@studio.com |
| `studio_owner_name` | Owner name for email salutation | Anna |

These are set once per studio on onboarding and stored as GHL sub-account custom values.

---

## Timing Table

| Step | Timing |
|---|---|
| Intent detection | Immediate on inbound message |
| Authentication | Immediate — blocks conversation until complete |
| Policy check | Calculated at time of request |
| Availability check | Immediate — reads from foundation data in GHL |
| Admin task created | Immediately after customer confirms summary |
| Customer confirmation | Immediately after task created |

---

## Exit Conditions

| Exit | Condition | GHL actions |
|---|---|---|
| Normal exit | Task created, customer confirmed | Task assigned, owner notified, confirmation sent |
| Auth failed | Identity cannot be verified | Error message sent, workflow ends |
| Not reschedule intent | Message classified as other intent | Route to appropriate use case |
| No availability after 3 attempts | Customer cannot find a suitable slot | Escalate to admin with note: "No suitable slot found — manual assistance needed" |

---

## GHL Implementation Notes

### Tags used by this use case

| Tag | Applied by | Removed by |
|---|---|---|
| `reschedule-pending` | This workflow when task is created | Studio owner manually after processing in Eversports |

### Custom fields read by this use case

| Field | Used for |
|---|---|
| `upcoming_session_name` | Identify booking to reschedule |
| `upcoming_session_date` | Policy check + task content |
| `upcoming_session_start_time` | Late cancel policy calculation |
| `active_package_type` | Task context |
| `active_package_name` | Task content |
| `active_sessions_data` | Availability check |
| `auth_verified` | Skip auth if already done |

### Custom fields written by this use case

| Field | Value |
|---|---|
| `reschedule_reason` | Customer-provided reason (if late cancel applies) |
| `reschedule_requested_date` | Customer's preferred new date |
| `reschedule_requested_time` | Customer's preferred new time |

### Foundation fields needed (to be confirmed)

The following fields must be added to the foundation sync to support this use case:

| Field | Source | Notes |
|---|---|---|
| `upcoming_session_name` | Active appointments report | Next booked session name |
| `upcoming_session_date` | Active appointments report | Next booked session date |
| `upcoming_session_start_time` | Active appointments report | Next booked session start time |
| `upcoming_session_end_time` | Active appointments report | Next booked session end time |
| `active_sessions_data` | Active appointments report | JSON of all upcoming sessions + availability |

---

## Open Questions / To Confirm

- [ ] Does the Eversports active appointments report include availability (open spots per session), or only confirmed bookings? Availability check logic depends on this.
- [ ] Should the bot handle customers with multiple upcoming bookings, or always default to the next upcoming one?
- [ ] After admin processes the reschedule in Eversports, should a second confirmation be sent to the customer automatically (triggered by foundation sync detecting the booking change), or is that done manually by the studio?
- [ ] Should late cancellation carry any consequence (e.g. session deducted from card regardless), or is it purely informational in this workflow?
