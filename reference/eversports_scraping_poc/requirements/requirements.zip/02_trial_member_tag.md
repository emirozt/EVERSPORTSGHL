# Use Case 02 — Trial → Member Tag

## Overview

**Goal:** Detect when a customer whose only historical product was a trial (name contains "trial" or "Probe") purchases a new non-trial package. Apply the `trial-converted` tag immediately, clean up active sequences, and notify the studio owner.

**Trigger source:** Foundation layer — daily sync (active products & membership packages)
**Channels:** GHL internal notification + email to studio owner
**GHL role:** Tag manager, sequence controller, notification sender
**AI role:** None — this is pure logic, no AI message generation

---

## Detection Logic

### What counts as a trial product

A product is considered a trial if its name contains any of the following (case-insensitive):

```
"trial" OR "probe"
```

Examples that match: "3-session Trial", "Probe Kurs", "Trial Pack", "Probestunde"

### What triggers the conversion

During the daily sync, the foundation updates each contact's `products_purchased` field. This use case fires when:

```
IF contact.products_purchased contains exactly 1 product
  AND that product name contains "trial" OR "probe"
  AND today's sync shows a NEW product added that does NOT contain "trial" or "probe"
THEN → conversion detected
```

In plain English: the customer previously had only a trial product, and the foundation has now detected a second product on their account that is not a trial.

### Important edge cases

```
IF contact has 2+ products already (was detected before) → skip, already processed
IF new product name also contains "trial" or "probe" → skip, not a real conversion
IF contact has no prior trial product on record → skip, not a trial customer
```

---

## Workflow Diagram Description

```
[Foundation daily sync runs]
        │
        ▼
[Check each updated contact's products_purchased]
        │
        ▼
[Gate: exactly 1 prior product AND name contains "trial"/"probe"?]
   No  ──► Skip contact
   Yes ──► Continue
        │
        ▼
[Gate: new non-trial product detected in today's sync?]
   No  ──► Skip contact
   Yes ──► Continue
        │
        ▼
[Gate: contact has tag "trial-follow-up-active"?]
   Yes ──► Remove from automation + remove tag "trial-follow-up-active"
   No  ──► Continue
        │
        ▼
[Apply tag: "trial-converted"]
[Remove tag: "trial-active" (if present)]
[Remove tag: "trial-last-session" (if present)]
        │
        ▼
[Update GHL custom field: converted_package_name = new product name]
        │
        ▼
[Send GHL internal notification to studio owner]
[Send email to studio owner]
        │
        ▼
[Done]
```

---

## Phase 1 — Detection (runs as part of foundation daily sync)

### GHL trigger

**Trigger:** Contact updated (by foundation sync) where `products_purchased` field changes.

The foundation script compares the previous value of `products_purchased` against the new value after each sync. If a new non-trial product is added and the contact had only a trial product before, it applies the GHL tag `trial-purchase-detected` to the contact.

This tag fires the GHL automation for use case 02.

```
Foundation script logic (pseudocode):

FOR each contact updated in today's sync:
  prior_products = contact.products_purchased (before sync)
  new_products   = contact.products_purchased (after sync)

  prior_trial_only = (
    len(prior_products) == 1 AND
    ("trial" in prior_products[0].name.lower() OR
     "probe" in prior_products[0].name.lower())
  )

  new_non_trial = [
    p for p in new_products
    if "trial" not in p.name.lower()
    and "probe" not in p.name.lower()
    and p not in prior_products
  ]

  IF prior_trial_only AND len(new_non_trial) > 0:
    contact.new_package_name = new_non_trial[0].name
    apply GHL tag: "trial-purchase-detected"
```

---

## Phase 2 — GHL Automation

**GHL trigger:** Contact tag added = `trial-purchase-detected`

### Step 1 — Check and clean up active sequences

```
IF contact.tags contains "trial-follow-up-active":
  Remove contact from automation: "Trial Conversion Follow-Up Sequence"
  Remove tag: "trial-follow-up-active"
```

### Step 2 — Apply conversion tags

```
Apply tag:  "trial-converted"
Remove tag: "trial-active"        (if present)
Remove tag: "trial-last-session"  (if present)
Remove tag: "trial-purchase-detected"  (cleanup trigger tag)
```

### Step 3 — Update custom field

```
Set custom field: converted_package_name = contact.new_package_name
Set custom field: conversion_date = today
```

### Step 4 — Notify studio owner

#### GHL internal notification

```
Type: Task or Alert
Assigned to: studio owner (GHL user)
Title: "New trial conversion — [first_name] [last_name]"
Body:
  "[first_name] [last_name] has converted from their trial.
   New package purchased: [converted_package_name]
   Date: [conversion_date]"
```

#### Email to studio owner

```
To: [studio_owner_email]  (GHL sub-account setting)
Subject: "Trial converted — [first_name] [last_name]"
Body:
  Hi [owner_name],

  Great news! [first_name] [last_name] has just purchased a new package
  after completing their trial.

  Package purchased: [converted_package_name]
  Conversion date: [conversion_date]

  You can view their contact here: [GHL contact link]

  — Your automation system
```

---

## Exit Conditions

This use case has a single linear flow with no branches beyond the detection gates. Once all steps complete, the workflow ends.

| Exit | Condition | GHL actions |
|---|---|---|
| Conversion processed | New non-trial product detected on trial-only contact | Tags updated, sequences stopped, owner notified |
| Skipped — not trial only | Contact had more than 1 prior product | No action |
| Skipped — new product is also trial | New product name contains "trial" or "probe" | No action |
| Skipped — no prior trial | Contact had no trial product on record | No action |

---

## GHL Implementation Notes

### Tags used by this use case

| Tag | Applied by | Removed by |
|---|---|---|
| `trial-purchase-detected` | Foundation sync script | This workflow (cleanup after trigger) |
| `trial-converted` | This workflow | Never removed |
| `trial-active` | Foundation layer | This workflow on conversion |
| `trial-last-session` | Foundation layer | This workflow on conversion |
| `trial-follow-up-active` | Use case 01 | This workflow if sequence was active |

### Custom fields written by this use case

| Field | Value set |
|---|---|
| `converted_package_name` | Name of the newly purchased non-trial product |
| `conversion_date` | Date the conversion was detected |

### Custom fields read by this use case

| Field | Used for |
|---|---|
| `products_purchased` | Core detection logic |
| `active_package_name` | Cross-reference during detection |
| `first_name`, `last_name` | Owner notification content |

### Relationship to use case 01

This use case acts as a safety net for use case 01. If a customer buys a new package through any channel (direct on Eversports website, in-studio, etc.) without going through the follow-up chatbot, this use case catches it via the foundation sync and ensures:

- The follow-up sequence is stopped cleanly
- The correct conversion tags are applied
- The owner is notified regardless of how the conversion happened

---

## Open Questions / To Confirm

- [ ] Should `trial-purchase-detected` tag be removed by the foundation script or by the GHL workflow? (Current spec: removed by GHL workflow as cleanup step.)
- [ ] If a customer buys two new packages on the same day, should both be recorded or just the first detected?
- [ ] Is `studio_owner_email` stored as a GHL sub-account setting, or does it need to be a custom field?
